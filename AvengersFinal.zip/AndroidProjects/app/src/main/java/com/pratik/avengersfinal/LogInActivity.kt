package com.pratik.avengersfinal

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class LogInActivity : AppCompatActivity() {


    lateinit var etmobilenumber: EditText
    lateinit var etpassword: EditText
    lateinit var btlogin: Button
    lateinit var txtforgotpassword: TextView
    lateinit var txtregisteryourself: TextView
    val validmobilenumber = "1234567890"
    val validpassword = arrayOf("tony", "steve", "thor", "thanos")
    lateinit var sharedPreferences: SharedPreferences



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sharedPreferences=getSharedPreferences(getString(R.string.preference_file_name),  Context.MODE_PRIVATE)
        val isLoggedIn=sharedPreferences.getBoolean("isLoggedIn",false)

        setContentView(R.layout.activity_login)
        if(isLoggedIn)
        {
            val intent=Intent(this@LogInActivity,MainActivity::class.java)
            startActivity(intent)
            finish()
        }

        title = "Log In"

        etmobilenumber = findViewById(R.id.etmobilenumber)
        etpassword = findViewById(R.id.etpassword)
        btlogin = findViewById(R.id.btlogin)
        txtforgotpassword = findViewById(R.id.txtforgotpassword)
        txtregisteryourself = findViewById(R.id.txtregisteryourself)



        btlogin.setOnClickListener {
            val mobilenumber = etmobilenumber.text.toString()
            val password = etpassword.text.toString()
            var nameOfAvenger = "Avengers"
            val intent = Intent(this@LogInActivity, MainActivity::class.java)
            if (mobilenumber == validmobilenumber) {
                if (password == validpassword[0]) {

                    nameOfAvenger = "Iron Man"
                    savedPreferences(nameOfAvenger)

                    startActivity(intent)
                } else if (password == validpassword[1]) {

                    nameOfAvenger = "Captain America"
                    savedPreferences(nameOfAvenger)

                    startActivity(intent)
                } else if (password == validpassword[2]) {

                    nameOfAvenger = "Thor"
                    savedPreferences(nameOfAvenger)

                    startActivity(intent)
                } else if (password == validpassword[3]) {

                    nameOfAvenger = "The Avengers"
                    savedPreferences(nameOfAvenger)

                    startActivity(intent)
                }
            } else {
                Toast.makeText(this@LogInActivity, "Invalid Credentials", Toast.LENGTH_LONG).show()
            }
        }
    }

    override fun onPause() {
        super.onPause()
        finish()
    }
    fun savedPreferences(title:String)
    {
        sharedPreferences.edit().putBoolean("isLoggedIn",true).apply()
        sharedPreferences.edit().putString("Title",title).apply()
    }
}


